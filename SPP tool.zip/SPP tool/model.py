
import pandas as pd
import pickle

dataset = pd.read_csv('SPVDataset.csv')

X = dataset.iloc[:, :4]

y = dataset.iloc[:, -1]

from sklearn.linear_model import LinearRegression
regressor = LinearRegression()

regressor.fit(X, y)

pickle.dump(regressor, open('model.pkl','wb'))

model = pickle.load(open('model.pkl','rb'))
print(model.predict([[65, 27, 2, 6]]))